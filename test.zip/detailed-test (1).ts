// features/investmentAllocation.feature
Feature: app Investment Allocation
  As a app account holder
  I want to set investment pool allocations
  So that I can manage my charitable investments efficiently

  Background:
    Given I am on the app login page

  Scenario: Login and set equal investment allocations
    When I login with username "password" and password "password"
    And I navigate to the charitable investment allocations page
    And I enter equal percentage values for all investment pools
    And I click the next button
    Then I should be taken to the review allocations page
    And the total allocation should equal 100 percent

  Scenario: Login and set custom investment allocations
    When I login with username "password" and password "password"
    And I navigate to the charitable investment allocations page
    And I enter the following custom allocations:
      | Pool Name                  | Allocation |
      | app Money Market        | 20         |
      | app Total Stock Market  | 40         |
      | app International Index | 30         |
      | app Fixed Income        | 10         |
    And I click the next button
    Then I should be taken to the review allocations page
    And the total allocation should equal 100 percent

  Scenario: Validate error for invalid allocations
    When I login with username "password" and password "password"
    And I navigate to the charitable investment allocations page
    And I enter the following custom allocations:
      | Pool Name                  | Allocation |
      | app Money Market        | 30         |
      | app Total Stock Market  | 40         |
      | app International Index | 40         |
      | app Fixed Income        | 10         |
    And I click the next button
    Then I should see an error message about invalid total allocation

// step-definitions/investmentAllocation.steps.ts
import { Given, When, Then, DataTable } from '@wdio/cucumber-framework';
import { expect } from 'chai';
import LoginPage from '../pageobjects/login.page';
import DashboardPage from '../pageobjects/dashboard.page';
import AllocationLandingPage from '../pageobjects/allocationLanding.page';
import EnterAllocationsPage from '../pageobjects/enterAllocations.page';
import ReviewAllocationsPage from '../pageobjects/reviewAllocations.page';
import logger from '../utils/logger';

Given('I am on the app login page', async () => {
    logger.info('Navigating to app login page');
    await LoginPage.open();
    await LoginPage.waitForPageLoad();
    const title = await browser.getTitle();
    expect(title).to.include('Login to app', 'Wrong page title');
    logger.info('Successfully loaded app login page');
});

When('I login with username {string} and password {string}', async (username: string, password: string) => {
    try {
        logger.info(`Attempting to login with username: ${username}`);
        await LoginPage.login(username, password);
        await DashboardPage.waitForPageLoad();
        logger.info('Login successful');
    } catch (error) {
        logger.error(`Login failed: ${error}`);
        throw new Error(`Failed to login: ${error}`);
    }
});

When('I navigate to the charitable investment allocations page', async () => {
    try {
        logger.info('Navigating to allocations landing page');
        await browser.url('https://client.app.com/app/charitable/investments/#/allocations/landingpage');
        await AllocationLandingPage.waitForPageLoad();
        logger.info('Successfully loaded allocations landing page');
        
        logger.info('Navigating to enter allocations page');
        await browser.url('https://client.app.com/app/charitable/investments/#/allocations/enterallocations');
        await EnterAllocationsPage.waitForPageLoad();
        logger.info('Successfully loaded enter allocations page');
    } catch (error) {
        logger.error(`Navigation failed: ${error}`);
        throw new Error(`Failed to navigate to allocations page: ${error}`);
    }
});

When('I enter equal percentage values for all investment pools', async () => {
    try {
        logger.info('Entering equal allocation values for all investment pools');
        await EnterAllocationsPage.enterEqualAllocationValues();
        logger.info('Successfully entered equal allocation values');
    } catch (error) {
        logger.error(`Failed to enter allocation values: ${error}`);
        throw new Error(`Failed to enter allocation values: ${error}`);
    }
});

When('I enter the following custom allocations:', async (dataTable: DataTable) => {
    try {
        logger.info('Entering custom allocation values');
        const allocations = dataTable.hashes();
        await EnterAllocationsPage.enterCustomAllocationValues(allocations);
        logger.info('Successfully entered custom allocation values');
    } catch (error) {
        logger.error(`Failed to enter custom allocation values: ${error}`);
        throw new Error(`Failed to enter custom allocation values: ${error}`);
    }
});

When('I click the next button', async () => {
    try {
        logger.info('Clicking next button');
        await EnterAllocationsPage.clickNextButton();
        logger.info('Successfully clicked next button');
    } catch (error) {
        logger.error(`Failed to click next button: ${error}`);
        throw new Error(`Failed to click next button: ${error}`);
    }
});

Then('I should be taken to the review allocations page', async () => {
    try {
        logger.info('Verifying navigation to review allocations page');
        await ReviewAllocationsPage.waitForPageLoad();
        const currentUrl = await browser.getUrl();
        expect(currentUrl).to.include('/reviewallocations', 'Not redirected to review allocations page');
        logger.info('Successfully navigated to review allocations page');
    } catch (error) {
        logger.error(`Failed to verify navigation to review page: ${error}`);
        throw new Error(`Failed to verify navigation to review page: ${error}`);
    }
});

Then('the total allocation should equal 100 percent', async () => {
    try {
        logger.info('Verifying total allocation is 100%');
        const totalAllocation = await ReviewAllocationsPage.getTotalAllocation();
        expect(totalAllocation).to.equal(100, `Total allocation is ${totalAllocation}%, expected 100%`);
        logger.info('Successfully verified total allocation equals 100%');
    } catch (error) {
        logger.error(`Failed to verify total allocation: ${error}`);
        throw new Error(`Failed to verify total allocation: ${error}`);
    }
});

Then('I should see an error message about invalid total allocation', async () => {
    try {
        logger.info('Verifying error message for invalid allocation');
        const errorMessage = await EnterAllocationsPage.getAllocationErrorMessage();
        expect(errorMessage).to.include('total must equal 100%', 'Incorrect or missing error message');
        logger.info('Successfully verified error message for invalid allocation');
    } catch (error) {
        logger.error(`Failed to verify error message: ${error}`);
        throw new Error(`Failed to verify error message: ${error}`);
    }
});

// pageobjects/login.page.ts
import Page from './page';
import logger from '../utils/logger';

class LoginPage extends Page {
    get inputUsername() { return $('#loginId'); }
    get inputPassword() { return $('#password'); }
    get btnLogin() { return $('.login-button'); }
    get loginForm() { return $('#loginForm'); }
    get errorMessage() { return $('.login-error-message'); }

    async open() {
        logger.debug('Opening login page');
        await browser.url('https://client.app.com/Areas/Access/Login');
    }

    async waitForPageLoad() {
        logger.debug('Waiting for login page to load');
        await this.loginForm.waitForDisplayed({ 
            timeout: 20000,
            timeoutMsg: 'Login form not displayed after timeout'
        });
    }

    async login(username: string, password: string) {
        logger.debug('Setting username');
        await this.inputUsername.waitForClickable();
        await this.inputUsername.setValue(username);
        
        logger.debug('Setting password');
        await this.inputPassword.waitForClickable();
        await this.inputPassword.setValue(password);
        
        logger.debug('Clicking login button');
        await this.btnLogin.waitForClickable();
        await this.btnLogin.click();
        
        // Check for login errors
        if (await this.errorMessage.isDisplayed()) {
            const error = await this.errorMessage.getText();
            logger.error(`Login error: ${error}`);
            throw new Error(`Login failed: ${error}`);
        }
    }
}

export default new LoginPage();

// pageobjects/dashboard.page.ts
import Page from './page';
import logger from '../utils/logger';

class DashboardPage extends Page {
    get dashboardContainer() { return $('.dashboard-container'); }
    get accountSummary() { return $('.account-summary'); }
    get userProfileInfo() { return $('.user-profile-info'); }

    async waitForPageLoad() {
        logger.debug('Waiting for dashboard page to load');
        await this.dashboardContainer.waitForDisplayed({ 
            timeout: 30000,
            timeoutMsg: 'Dashboard not displayed after login timeout'
        });
        await browser.pause(2000); // Additional wait for dynamic content
    }

    async isLoggedIn() {
        return await this.userProfileInfo.isDisplayed();
    }
}

export default new DashboardPage();

// pageobjects/allocationLanding.page.ts
import Page from './page';
import logger from '../utils/logger';

class AllocationLandingPage extends Page {
    get pageContainer() { return $('.allocation-landing-container, .charitable-allocation-landing'); }
    get continueButton() { return $('.continue-button, button=Continue'); }
    get pageTitle() { return $('h1=Investment Pool Allocations'); }

    async waitForPageLoad() {
        logger.debug('Waiting for allocation landing page to load');
        await this.pageTitle.waitForDisplayed({ 
            timeout: 20000, 
            timeoutMsg: 'Allocation landing page title not displayed after timeout' 
        });
        await this.pageContainer.waitForDisplayed({ 
            timeout: 10000,
            timeoutMsg: 'Allocation landing page container not displayed after timeout'
        });
    }

    async clickContinue() {
        logger.debug('Clicking continue button on landing page');
        await this.continueButton.waitForClickable();
        await this.continueButton.click();
    }
}

export default new AllocationLandingPage();

// pageobjects/enterAllocations.page.ts
import Page from './page';
import logger from '../utils/logger';

class EnterAllocationsPage extends Page {
    get pageContainer() { return $('.enter-allocations-container, .charitable-enter-allocations'); }
    get pageTitle() { return $('h1=Enter Allocations'); }
    get allInputFields() { return $$('.investment-pool-input, input[type="text"]'); }
    get allPoolNames() { return $$('.investment-pool-name, .pool-name'); }
    get btnNext() { return $('.next-button, button=Next'); }
    get totalAllocation() { return $('.total-allocation, .allocation-total'); }
    get errorMessage() { return $('.error-message, .allocation-error'); }

    async waitForPageLoad() {
        logger.debug('Waiting for enter allocations page to load');
        await this.pageTitle.waitForDisplayed({ 
            timeout: 20000,
            timeoutMsg: 'Enter allocations page title not displayed after timeout'
        });
        await this.pageContainer.waitForDisplayed({ 
            timeout: 10000,
            timeoutMsg: 'Enter allocations page container not displayed after timeout'
        });
        
        // Wait for all investment pool inputs to be loaded
        const inputFields = await this.allInputFields;
        logger.debug(`Found ${inputFields.length} allocation input fields`);
        if (inputFields.length === 0) {
            throw new Error('No allocation input fields found on the page');
        }
        
        await browser.pause(1000); // Additional wait for any dynamic loading
    }

    async enterEqualAllocationValues() {
        const inputFields = await this.allInputFields;
        const totalFields = inputFields.length;
        
        logger.debug(`Entering equal allocations across ${totalFields} fields`);
        
        if (totalFields === 0) {
            throw new Error('No allocation input fields found');
        }
        
        // Calculate an equal distribution across all pools
        let equalValue = Math.floor(100 / totalFields);
        let remainingValue = 100;
        
        // Enter values for each investment pool
        for (let i = 0; i < totalFields; i++) {
            let valueToEnter;
            
            // For the last field, use the remaining value to ensure total is exactly 100%
            if (i === totalFields - 1) {
                valueToEnter = remainingValue;
            } else {
                valueToEnter = equalValue;
                remainingValue -= equalValue;
            }
            
            logger.debug(`Setting field ${i+1} to value: ${valueToEnter}%`);
            await inputFields[i].waitForClickable();
            await inputFields[i].clearValue();
            await inputFields[i].setValue(valueToEnter.toString());
            await browser.pause(500); // Small pause between entries
        }
        
        // Verify total allocation
        const total = await this.getCurrentTotalAllocation();
        logger.debug(`Current total allocation: ${total}%`);
        
        if (total !== 100) {
            logger.warn(`Total allocation is ${total}%, adjusting to reach 100%`);
            // Adjust last field if needed
            const lastField = inputFields[totalFields - 1];
            const currentValue = parseInt(await lastField.getValue());
            const adjustedValue = currentValue + (100 - total);
            
            await lastField.clearValue();
            await lastField.setValue(adjustedValue.toString());
            
            // Re-verify
            const newTotal = await this.getCurrentTotalAllocation();
            logger.debug(`Adjusted total allocation: ${newTotal}%`);
            
            if (newTotal !== 100) {
                throw new Error(`Failed to set total allocation to 100%. Current total: ${newTotal}%`);
            }
        }
    }

    async enterCustomAllocationValues(allocations: { 'Pool Name': string, Allocation: string }[]) {
        const poolNames = await this.allPoolNames;
        const inputFields = await this.allInputFields;
        
        if (poolNames.length === 0 || inputFields.length === 0) {
            throw new Error('Pool names or input fields not found on the page');
        }
        
        logger.debug(`Setting custom allocations for ${allocations.length} pools`);
        
        // Clear all existing values first
        for (const input of inputFields) {
            await input.clearValue();
        }
        
        // Map of pool names to found values (for debugging)
        const poolsFound: Record<string, boolean> = {};
        
        // Enter custom values
        for (const allocation of allocations) {
            let found = false;
            
            // Find the input field corresponding to the pool name
            for (let i = 0; i < poolNames.length; i++) {
                const poolNameText = await poolNames[i].getText();
                
                if (poolNameText.includes(allocation['Pool Name'])) {
                    logger.debug(`Setting ${allocation['Pool Name']} to ${allocation.Allocation}%`);
                    await inputFields[i].waitForClickable();
                    await inputFields[i].setValue(allocation.Allocation);
                    poolsFound[allocation['Pool Name']] = true;
                    found = true;
                    break;
                }
            }
            
            if (!found) {
                logger.warn(`Pool "${allocation['Pool Name']}" not found on page`);
                // Instead of throwing an error, continue with other allocations
                poolsFound[allocation['Pool Name']] = false;
            }
        }
        
        // Log pools that were not found
        for (const pool in poolsFound) {
            if (!poolsFound[pool]) {
                logger.warn(`Pool "${pool}" specified in test data was not found on the page`);
            }
        }
        
        // Verify total allocation
        const total = await this.getCurrentTotalAllocation();
        logger.debug(`Total allocation after custom entries: ${total}%`);
    }

    async getCurrentTotalAllocation(): Promise<number> {
        try {
            await this.totalAllocation.waitForDisplayed({ timeout: 5000 });
            const totalText = await this.totalAllocation.getText();
            // Extract number from text like "Total: 100%" or "100%"
            const totalMatch = totalText.match(/(\d+)/);
            if (totalMatch) {
                return parseInt(totalMatch[1]);
            } else {
                // If no total element is displayed, calculate from input fields
                const inputFields = await this.allInputFields;
                let sum = 0;
                for (const field of inputFields) {
                    const value = await field.getValue();
                    if (value && !isNaN(parseInt(value))) {
                        sum += parseInt(value);
                    }
                }
                return sum;
            }
        } catch (error) {
            logger.warn(`Error getting total allocation: ${error}`);
            return 0;
        }
    }

    async clickNextButton() {
        logger.debug('Clicking next button');
        await this.btnNext.waitForClickable({ timeout: 10000 });
        await this.btnNext.click();
        await browser.pause(1000); // Wait for any validation to occur
    }

    async getAllocationErrorMessage(): Promise<string> {
        try {
            await this.errorMessage.waitForDisplayed({ timeout: 5000 });
            const message = await this.errorMessage.getText();
            logger.debug(`Error message displayed: ${message}`);
            return message;
        } catch (error) {
            logger.warn(`No error message displayed: ${error}`);
            return '';
        }
    }
}

export default new EnterAllocationsPage();

// pageobjects/reviewAllocations.page.ts
import Page from './page';
import logger from '../utils/logger';

class ReviewAllocationsPage extends Page {
    get pageContainer() { return $('.review-allocations-container, .charitable-review-allocations'); }
    get pageTitle() { return $('h1=Review Allocations'); }
    get allocationSummary() { return $('.allocation-summary'); }
    get allocationItems() { return $$('.allocation-item, .pool-allocation'); }
    get totalAllocationDisplay() { return $('.total-allocation, .allocation-total'); }
    get submitButton() { return $('.submit-button, button=Submit'); }
    get cancelButton() { return $('.cancel-button, button=Cancel'); }

    async waitForPageLoad() {
        logger.debug('Waiting for review allocations page to load');
        await this.pageTitle.waitForDisplayed({ 
            timeout: 20000,
            timeoutMsg: 'Review allocations page title not displayed after timeout'
        });
        await this.pageContainer.waitForDisplayed({ 
            timeout: 10000,
            timeoutMsg: 'Review allocations page container not displayed after timeout'
        });
    }

    async getTotalAllocation(): Promise<number> {
        await this.totalAllocationDisplay.waitForDisplayed();
        const totalText = await this.totalAllocationDisplay.getText();
        const totalMatch = totalText.match(/(\d+)/);
        if (totalMatch) {
            return parseInt(totalMatch[1]);
        }
        
        // If no total element with pattern match, calculate manually
        logger.debug('Calculating total allocation from individual items');
        const items = await this.allocationItems;
        let total = 0;
        
        for (const item of items) {
            const text = await item.getText();
            const percentMatch = text.match(/(\d+)%/);
            if (percentMatch) {
                total += parseInt(percentMatch[1]);
            }
        }
        
        return total;
    }

    async getAllocationDetails() {
        const items = await this.allocationItems;
        const allocations: Record<string, number> = {};
        
        for (const item of items) {
            const text = await item.getText();
            const match = text.match(/(.*?)\s*(\d+)%/);
            if (match) {
                const poolName = match[1].trim();
                const percentage = parseInt(match[2]);
                allocations[poolName] = percentage;
            }
        }
        
        return allocations;
    }

    async clickSubmit() {
        logger.debug('Clicking submit button');
        await this.submitButton.waitForClickable();
        await this.submitButton.click();
    }
}

export default new ReviewAllocationsPage();

// pageobjects/page.ts
export default class Page {
    async open(path: string) {
        await browser.url(path);
    }
    
    async takeScreenshot(name: string) {
        await browser.saveScreenshot(`./screenshots/${name}_${new Date().getTime()}.png`);
    }
}

// utils/logger.ts
import winston from 'winston';

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.printf(info => `${info.timestamp} ${info.level}: ${info.message}`)
    ),
    transports: [
        new winston.transports.File({ filename: 'test-execution.log' }),
        new winston.transports.Console({
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.simple()
            )
        })
    ]
});

export default logger;

// wdio.conf.ts
export const config = {
    runner: 'local',
    specs: [
        './features/**/*.feature'
    ],
    exclude: [],
    maxInstances: 1,
    capabilities: [{
        browserName: 'chrome',
        acceptInsecureCerts: true,
        'goog:chromeOptions': {
            args: [
                '--disable-web-security',
                '--disable-dev-shm-usage',
                '--no-sandbox',
                '--window-size=1920,1080'
            ]
        }
    }],
    logLevel: 'info',
    bail: 0,
    baseUrl: 'https://client.app.com',
    waitforTimeout: 15000,
    connectionRetryTimeout: 120000,
    connectionRetryCount: 3,
    services: ['chromedriver', 'intercept'],
    framework: 'cucumber',
    reporters: [
        'spec',
        ['allure', {
            outputDir: 'allure-results',
            disableWebdriverStepsReporting: true,
            disableWebdriverScreenshotsReporting: false,
        }],
        ['junit', {
            outputDir: 'junit-results',
            outputFileFormat: function(options) {
                return `results-${options.cid}.xml`;
            }
        }]
    ],
    cucumberOpts: {
        require: ['./step-definitions/**/*.ts'],
        backtrace: false,
        requireModule: ['ts-node/register'],
        dryRun: false,
        failFast: false,
        snippets: true,
        source: true,
        strict: false,
        tagExpression: '',
        timeout: 60000,
        ignoreUndefinedDefinitions: false
    },
    autoCompileOpts: {
        autoCompile: true,
        tsNodeOpts: {
            transpileOnly: true,
            project: 'tsconfig.json'
        }
    },
    // Hooks for setup, teardown, etc.
    before: async function (capabilities, specs) {
        // Setup before tests run
        logger.info('Starting test execution');
    },
    afterTest: async function(test, context, { error, result, duration, passed, retries }) {
        // Take screenshot if test fails
        if (!passed) {
            logger.error(`Test failed: ${test.title}`);
            await browser.takeScreenshot();
        }
    },
    after: async function(result) {
        // Cleanup after all tests complete
        logger.info(`Test execution completed with result: ${result}`);
    }
};

// package.json (for reference)
/*
{
  "name": "app-charitable-tests",
  "version": "1.0.0",
  "description": "UI Automation Tests for app",
  "main": "index.js",
  "scripts": {
    "test": "wdio run wdio.conf.ts",
    "report": "allure generate allure-results --clean && allure open"
  },
  "dependencies": {
    "@wdio/allure-reporter": "^7.16.14",
    "@wdio/cli": "^7.16.14",
    "@wdio/cucumber-framework": "^7.16.14",
    "@wdio/junit-reporter": "^7.16.14",
    "@wdio/local-runner": "^7.16.14",
    "@wdio/spec-reporter": "^7.16.14",
    "chai": "^4.3.4",
    "ts-node": "^10.4.0",
    "typescript": "^4.5.4",
    "webdriverio": "^7.16.14",
    "winston": "^3.3.3"
  }
}
*/

// tsconfig.json (for reference)
/*
{
  "compilerOptions": {
    "target": "es2019",
    "module": "commonjs",
    "moduleResolution": "node",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "outDir": "./dist",
    "types": [
      "node",
      "webdriverio/async",
      "@wdio/cucumber-framework",
      "expect-webdriverio"
    ]
  },
  "include": [
    "features/**/*",
    "step-definitions/**/*",
    "pageobjects/**/*",
    "utils/**/*",
    "wdio.conf.ts"
  ]
}
*/
