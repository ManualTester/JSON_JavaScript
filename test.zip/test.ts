// features/investmentAllocation.feature
Feature: app Investment Allocation
  As a app account holder
  I want to set investment pool allocations
  So that I can manage my charitable investments

  Scenario: Login and set investment allocations
    Given I am on the app login page
    When I login with valid credentials
    And I navigate to the investment allocations page
    And I enter values for all investment pools
    And I click the next button
    Then I should be taken to the next step of the allocation process

// step-definitions/investmentAllocation.steps.ts
import { Given, When, Then } from '@wdio/cucumber-framework';
import { expect } from 'chai';
import LoginPage from '../pageobjects/login.page';
import AllocationLandingPage from '../pageobjects/allocationLanding.page';
import EnterAllocationsPage from '../pageobjects/enterAllocations.page';

Given('I am on the app login page', async () => {
    await LoginPage.open();
    await expect(await browser.getTitle()).to.include('Login to app');
});

When('I login with valid credentials', async () => {
    await LoginPage.login('scfprod', 'sch44wab');
    await browser.pause(3000); // Wait for login to complete
});

When('I navigate to the investment allocations page', async () => {
    // First navigate to the allocations landing page
    await browser.url('https://client.app.com/app/charitable/investments/#/allocations/landingpage');
    await AllocationLandingPage.waitForPageLoad();
    
    // Then navigate to the enter allocations page
    await browser.url('https://client.app.com/app/charitable/investments/#/allocations/enterallocations');
    await EnterAllocationsPage.waitForPageLoad();
});

When('I enter values for all investment pools', async () => {
    await EnterAllocationsPage.enterAllocationValues();
});

When('I click the next button', async () => {
    await EnterAllocationsPage.clickNextButton();
});

Then('I should be taken to the next step of the allocation process', async () => {
    await browser.pause(2000); // Wait for navigation
    const currentUrl = await browser.getUrl();
    expect(currentUrl).to.not.include('/enterallocations');
    // Additional validation could be added here depending on the next page's URL pattern
});

// pageobjects/login.page.ts
import Page from './page';

class LoginPage extends Page {
    get inputUsername() { return $('#loginId'); }
    get inputPassword() { return $('#password'); }
    get btnLogin() { return $('.login-button'); }

    async open() {
        await browser.url('https://client.app.com/Areas/Access/Login');
    }

    async login(username: string, password: string) {
        await this.inputUsername.setValue(username);
        await this.inputPassword.setValue(password);
        await this.btnLogin.click();
    }
}

export default new LoginPage();

// pageobjects/allocationLanding.page.ts
import Page from './page';

class AllocationLandingPage extends Page {
    get pageContainer() { return $('.allocation-landing-container'); }

    async waitForPageLoad() {
        await this.pageContainer.waitForDisplayed({ timeout: 10000 });
    }
}

export default new AllocationLandingPage();

// pageobjects/enterAllocations.page.ts
import Page from './page';

class EnterAllocationsPage extends Page {
    get pageContainer() { return $('.enter-allocations-container'); }
    get allInputFields() { return $$('.investment-pool-input'); }
    get btnNext() { return $('.next-button'); }

    async waitForPageLoad() {
        await this.pageContainer.waitForDisplayed({ timeout: 10000 });
    }

    async enterAllocationValues() {
        const inputFields = await this.allInputFields;
        const totalFields = inputFields.length;
        
        // Calculate an equal distribution across all pools
        const equalValue = Math.floor(100 / totalFields);
        let remainingValue = 100;
        
        // Enter values for each investment pool
        for (let i = 0; i < totalFields; i++) {
            let valueToEnter;
            
            // For the last field, use the remaining value to ensure total is exactly 100%
            if (i === totalFields - 1) {
                valueToEnter = remainingValue;
            } else {
                valueToEnter = equalValue;
                remainingValue -= equalValue;
            }
            
            await inputFields[i].setValue(valueToEnter.toString());
            await browser.pause(500); // Small pause between entries
        }
    }

    async clickNextButton() {
        await this.btnNext.click();
    }
}

export default new EnterAllocationsPage();

// pageobjects/page.ts
export default class Page {
    async open(path: string) {
        await browser.url(path);
    }
}

// wdio.conf.ts
export const config = {
    runner: 'local',
    specs: [
        './features/**/*.feature'
    ],
    exclude: [],
    maxInstances: 1,
    capabilities: [{
        browserName: 'chrome',
        acceptInsecureCerts: true
    }],
    logLevel: 'info',
    bail: 0,
    baseUrl: 'https://client.app.com',
    waitforTimeout: 10000,
    connectionRetryTimeout: 120000,
    connectionRetryCount: 3,
    services: ['chromedriver'],
    framework: 'cucumber',
    reporters: ['spec'],
    cucumberOpts: {
        require: ['./step-definitions/**/*.ts'],
        backtrace: false,
        requireModule: ['ts-node/register'],
        dryRun: false,
        failFast: false,
        snippets: true,
        source: true,
        strict: false,
        tagExpression: '',
        timeout: 60000,
        ignoreUndefinedDefinitions: false
    },
    autoCompileOpts: {
        autoCompile: true,
        tsNodeOpts: {
            transpileOnly: true,
            project: 'tsconfig.json'
        }
    }
};
