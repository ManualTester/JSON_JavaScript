// Project Structure:
// ├── README.md
// ├── package.json
// ├── tsconfig.json
// ├── wdio.conf.ts
// ├── allure-reporter.config.js
// ├── src/
// │   ├── features/
// │   │   └── investmentAllocation.feature
// │   ├── step-definitions/
// │   │   └── investmentAllocation.steps.ts
// │   ├── pageObjects/
// │   │   ├── basePage.ts
// │   │   ├── loginPage.ts
// │   │   ├── dashboardPage.ts
// │   │   ├── investmentAllocationPage.ts
// │   │   └── reviewAllocationPage.ts
// │   ├── utils/
// │   │   ├── logger.ts
// │   │   ├── reporter.ts
// │   │   ├── constants.ts
// │   │   ├── helpers.ts
// │   │   └── testData.ts
// │   └── types/
// │       └── custom.d.ts

// src/features/investmentAllocation.feature
Feature: app Investment Allocation Management
  As a app account holder
  I want to manage my investment pool allocations
  So that I can effectively control my charitable investments

  Background:
    Given I am on the app login page
    When I login with valid credentials
    Then I should be successfully logged in
    When I navigate to the investment allocations page

  @smoke @regression
  Scenario: Set equal investment allocations across all pools
    When I set equal allocations across all investment pools
    Then the total allocation should equal 100%
    When I submit the allocations
    Then I should see a confirmation message
    And the allocations should be saved successfully

  @regression
  Scenario: Set custom investment allocations with specific percentages
    When I set the following investment allocations:
      | Pool Name                     | Allocation |
      | app Money Market           | 25         |
      | TIFF Multi-Asset              | 30         |
      | app Total Stock Market     | 15         |
      | app International Index    | 15         |
      | BlackRock Fixed-Income        | 15         |
    Then the total allocation should equal 100%
    When I submit the allocations
    Then I should see a confirmation message
    And the allocations should be saved successfully

  @regression @negative
  Scenario: Validate error when total allocation is over 100%
    When I set the following investment allocations:
      | Pool Name                     | Allocation |
      | app Money Market           | 30         |
      | TIFF Multi-Asset              | 30         |
      | app Total Stock Market     | 30         |
      | app International Index    | 20         |
    Then the total allocation should equal 110%
    When I submit the allocations
    Then I should see an error message stating "Total allocation must equal 100%"

  @regression @negative
  Scenario: Validate error when total allocation is under 100%
    When I set the following investment allocations:
      | Pool Name                     | Allocation |
      | app Money Market           | 20         |
      | TIFF Multi-Asset              | 20         |
      | app Total Stock Market     | 20         |
      | app International Index    | 20         |
    Then the total allocation should equal 80%
    When I submit the allocations
    Then I should see an error message stating "Total allocation must equal 100%"

  @regression @accessibility
  Scenario: Verify keyboard navigation through investment allocation fields
    When I tab through each investment allocation field
    And I enter values using only keyboard
    Then I should be able to complete the form without using a mouse
    And the total allocation should equal 100%

  @regression
  Scenario: Reset all allocations to default
    Given I have existing custom allocations
    When I click the reset button
    Then all allocation fields should be cleared
    And the total allocation should equal 0%

// src/step-definitions/investmentAllocation.steps.ts
import { Given, When, Then, DataTable } from '@wdio/cucumber-framework';
import { expect } from 'chai';
import allureReporter from '@wdio/allure-reporter';

import LoginPage from '../pageObjects/loginPage';
import DashboardPage from '../pageObjects/dashboardPage';
import InvestmentAllocationPage from '../pageObjects/investmentAllocationPage';
import ReviewAllocationPage from '../pageObjects/reviewAllocationPage';

import { logger } from '../utils/logger';
import { CREDENTIALS } from '../utils/constants';
import { takeScreenshot } from '../utils/helpers';

Given('I am on the app login page', async function() {
    allureReporter.addFeature('Login');
    allureReporter.addStory('Navigate to login page');
    
    try {
        logger.info('Navigating to app login page');
        await LoginPage.open();
        await LoginPage.waitForPageLoad();
        
        const title = await browser.getTitle();
        expect(title).to.include('Login to app', 'Login page title is incorrect');
        
        allureReporter.addAttachment('Screenshot - Login Page', await takeScreenshot(), 'image/png');
        logger.info('Successfully loaded app login page');
    } catch (error) {
        logger.error(`Failed to navigate to login page: ${error}`);
        allureReporter.addAttachment('Screenshot - Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to navigate to login page: ${error}`);
    }
});

When('I login with valid credentials', async function() {
    allureReporter.addFeature('Authentication');
    allureReporter.addStory('User login');
    
    try {
        logger.info('Attempting to login with valid credentials');
        await LoginPage.login(CREDENTIALS.username, CREDENTIALS.password);
        
        allureReporter.addAttachment('Screenshot - After Login Attempt', await takeScreenshot(), 'image/png');
        logger.info('Login credentials submitted successfully');
    } catch (error) {
        logger.error(`Login attempt failed: ${error}`);
        allureReporter.addAttachment('Screenshot - Login Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to login with valid credentials: ${error}`);
    }
});

Then('I should be successfully logged in', async function() {
    try {
        logger.info('Verifying successful login');
        await DashboardPage.waitForPageLoad();
        
        const isLoggedIn = await DashboardPage.isUserLoggedIn();
        expect(isLoggedIn).to.be.true;
        
        allureReporter.addAttachment('Screenshot - Dashboard', await takeScreenshot(), 'image/png');
        logger.info('User successfully logged in');
    } catch (error) {
        logger.error(`Failed to verify login success: ${error}`);
        allureReporter.addAttachment('Screenshot - Login Verification Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to verify login success: ${error}`);
    }
});

When('I navigate to the investment allocations page', async function() {
    allureReporter.addFeature('Navigation');
    allureReporter.addStory('Access investment allocation page');
    
    try {
        logger.info('Navigating to investment allocations page');
        await browser.url('https://client.app.com/app/charitable/investments/#/allocations/enterallocations');
        await InvestmentAllocationPage.waitForPageLoad();
        
        allureReporter.addAttachment('Screenshot - Allocation Page', await takeScreenshot(), 'image/png');
        logger.info('Successfully navigated to investment allocations page');
    } catch (error) {
        logger.error(`Failed to navigate to allocations page: ${error}`);
        allureReporter.addAttachment('Screenshot - Navigation Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to navigate to allocations page: ${error}`);
    }
});

When('I set equal allocations across all investment pools', async function() {
    allureReporter.addFeature('Allocation Management');
    allureReporter.addStory('Equal allocation distribution');
    
    try {
        logger.info('Setting equal allocations across all investment pools');
        await InvestmentAllocationPage.clearAllAllocations();
        await InvestmentAllocationPage.setEqualAllocationsAcrossAllPools();
        
        allureReporter.addAttachment('Screenshot - Equal Allocations', await takeScreenshot(), 'image/png');
        logger.info('Successfully set equal allocations');
    } catch (error) {
        logger.error(`Failed to set equal allocations: ${error}`);
        allureReporter.addAttachment('Screenshot - Equal Allocation Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to set equal allocations: ${error}`);
    }
});

When('I set the following investment allocations:', async function(dataTable: DataTable) {
    allureReporter.addFeature('Allocation Management');
    allureReporter.addStory('Custom allocation distribution');
    
    try {
        logger.info('Setting custom investment allocations');
        const allocations = dataTable.hashes();
        
        allureReporter.addAttachment(
            'Test Data - Custom Allocations', 
            JSON.stringify(allocations, null, 2), 
            'application/json'
        );
        
        await InvestmentAllocationPage.clearAllAllocations();
        await InvestmentAllocationPage.setCustomAllocations(allocations);
        
        allureReporter.addAttachment('Screenshot - Custom Allocations', await takeScreenshot(), 'image/png');
        logger.info('Successfully set custom allocations');
    } catch (error) {
        logger.error(`Failed to set custom allocations: ${error}`);
        allureReporter.addAttachment('Screenshot - Custom Allocation Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to set custom allocations: ${error}`);
    }
});

Then('the total allocation should equal {int}%', async function(expectedTotal: number) {
    try {
        logger.info(`Verifying total allocation equals ${expectedTotal}%`);
        const actualTotal = await InvestmentAllocationPage.getTotalAllocation();
        
        allureReporter.addAttachment(
            'Allocation Verification', 
            `Expected Total: ${expectedTotal}%\nActual Total: ${actualTotal}%`, 
            'text/plain'
        );
        
        expect(actualTotal).to.equal(expectedTotal, `Total allocation should be ${expectedTotal}% but was ${actualTotal}%`);
        logger.info(`Total allocation verified: ${actualTotal}%`);
    } catch (error) {
        logger.error(`Failed to verify total allocation: ${error}`);
        allureReporter.addAttachment('Screenshot - Total Verification Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to verify total allocation: ${error}`);
    }
});

When('I submit the allocations', async function() {
    allureReporter.addFeature('Allocation Management');
    allureReporter.addStory('Submit allocations');
    
    try {
        logger.info('Submitting allocations');
        await InvestmentAllocationPage.submitAllocations();
        
        allureReporter.addAttachment('Screenshot - After Submit', await takeScreenshot(), 'image/png');
        logger.info('Successfully submitted allocations');
    } catch (error) {
        logger.error(`Failed to submit allocations: ${error}`);
        allureReporter.addAttachment('Screenshot - Submit Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to submit allocations: ${error}`);
    }
});

Then('I should see a confirmation message', async function() {
    try {
        logger.info('Verifying confirmation message');
        await ReviewAllocationPage.waitForPageLoad();
        
        const isConfirmationDisplayed = await ReviewAllocationPage.isConfirmationDisplayed();
        expect(isConfirmationDisplayed).to.be.true;
        
        allureReporter.addAttachment('Screenshot - Confirmation Message', await takeScreenshot(), 'image/png');
        logger.info('Confirmation message verified');
    } catch (error) {
        logger.error(`Failed to verify confirmation message: ${error}`);
        allureReporter.addAttachment('Screenshot - Confirmation Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to verify confirmation message: ${error}`);
    }
});

Then('the allocations should be saved successfully', async function() {
    try {
        logger.info('Verifying allocations were saved');
        const savedAllocations = await ReviewAllocationPage.getAllSavedAllocations();
        const totalSaved = await ReviewAllocationPage.getTotalAllocation();
        
        allureReporter.addAttachment(
            'Saved Allocations', 
            JSON.stringify(savedAllocations, null, 2), 
            'application/json'
        );
        
        expect(totalSaved).to.equal(100, 'Total saved allocation should equal 100%');
        logger.info('Allocations saved successfully');
    } catch (error) {
        logger.error(`Failed to verify saved allocations: ${error}`);
        allureReporter.addAttachment('Screenshot - Save Verification Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to verify saved allocations: ${error}`);
    }
});

Then('I should see an error message stating {string}', async function(expectedErrorMessage: string) {
    try {
        logger.info(`Verifying error message: "${expectedErrorMessage}"`);
        const errorMessage = await InvestmentAllocationPage.getErrorMessage();
        
        expect(errorMessage).to.include(expectedErrorMessage);
        
        allureReporter.addAttachment('Screenshot - Error Message', await takeScreenshot(), 'image/png');
        allureReporter.addAttachment('Error Verification', 
            `Expected: ${expectedErrorMessage}\nActual: ${errorMessage}`, 
            'text/plain');
        
        logger.info(`Error message verified: "${errorMessage}"`);
    } catch (error) {
        logger.error(`Failed to verify error message: ${error}`);
        allureReporter.addAttachment('Screenshot - Error Verification Failure', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to verify error message: ${error}`);
    }
});

When('I tab through each investment allocation field', async function() {
    allureReporter.addFeature('Accessibility');
    allureReporter.addStory('Keyboard navigation');
    
    try {
        logger.info('Testing keyboard navigation through allocation fields');
        await InvestmentAllocationPage.navigateFieldsWithTabKey();
        
        allureReporter.addAttachment('Screenshot - Keyboard Navigation', await takeScreenshot(), 'image/png');
        logger.info('Successfully navigated fields with keyboard');
    } catch (error) {
        logger.error(`Failed to navigate with keyboard: ${error}`);
        allureReporter.addAttachment('Screenshot - Keyboard Navigation Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to navigate with keyboard: ${error}`);
    }
});

When('I enter values using only keyboard', async function() {
    try {
        logger.info('Entering values using only keyboard');
        await InvestmentAllocationPage.enterValuesUsingKeyboardOnly();
        
        allureReporter.addAttachment('Screenshot - Keyboard Input', await takeScreenshot(), 'image/png');
        logger.info('Successfully entered values using keyboard');
    } catch (error) {
        logger.error(`Failed to enter values with keyboard: ${error}`);
        allureReporter.addAttachment('Screenshot - Keyboard Input Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to enter values with keyboard: ${error}`);
    }
});

Then('I should be able to complete the form without using a mouse', async function() {
    try {
        logger.info('Verifying form can be completed with keyboard only');
        const isCompletable = await InvestmentAllocationPage.isFormCompletableWithKeyboard();
        
        expect(isCompletable).to.be.true;
        
        allureReporter.addAttachment('Screenshot - Keyboard Form Completion', await takeScreenshot(), 'image/png');
        logger.info('Form is completable with keyboard only');
    } catch (error) {
        logger.error(`Failed to verify keyboard form completion: ${error}`);
        allureReporter.addAttachment('Screenshot - Keyboard Completion Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to verify keyboard form completion: ${error}`);
    }
});

Given('I have existing custom allocations', async function() {
    try {
        logger.info('Setting up existing custom allocations');
        await InvestmentAllocationPage.setDefaultTestAllocations();
        
        const totalAllocation = await InvestmentAllocationPage.getTotalAllocation();
        expect(totalAllocation).to.equal(100);
        
        allureReporter.addAttachment('Screenshot - Existing Allocations', await takeScreenshot(), 'image/png');
        logger.info('Successfully set up existing allocations');
    } catch (error) {
        logger.error(`Failed to set up existing allocations: ${error}`);
        allureReporter.addAttachment('Screenshot - Setup Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to set up existing allocations: ${error}`);
    }
});

When('I click the reset button', async function() {
    allureReporter.addFeature('Allocation Management');
    allureReporter.addStory('Reset allocations');
    
    try {
        logger.info('Clicking reset button');
        await InvestmentAllocationPage.clickResetButton();
        
        allureReporter.addAttachment('Screenshot - After Reset', await takeScreenshot(), 'image/png');
        logger.info('Successfully clicked reset button');
    } catch (error) {
        logger.error(`Failed to click reset button: ${error}`);
        allureReporter.addAttachment('Screenshot - Reset Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to click reset button: ${error}`);
    }
});

Then('all allocation fields should be cleared', async function() {
    try {
        logger.info('Verifying all allocation fields are cleared');
        const areFieldsCleared = await InvestmentAllocationPage.areAllFieldsCleared();
        
        expect(areFieldsCleared).to.be.true;
        
        allureReporter.addAttachment('Screenshot - Cleared Fields', await takeScreenshot(), 'image/png');
        logger.info('All allocation fields are cleared');
    } catch (error) {
        logger.error(`Failed to verify fields are cleared: ${error}`);
        allureReporter.addAttachment('Screenshot - Clear Verification Error', await takeScreenshot(), 'image/png');
        throw new Error(`Failed to verify fields are cleared: ${error}`);
    }
});

// src/pageObjects/basePage.ts
export default class BasePage {
    /**
     * Opens a sub page of the page
     * @param path path of the sub page (e.g. /path/to/page.html)
     */
    public async open(path?: string): Promise<void> {
        await browser.url(path || '/');
    }
    
    /**
     * Wait for an element to be displayed with proper error handling
     * @param element WebdriverIO element
     * @param timeout Timeout in milliseconds
     * @param message Error message
     */
    public async waitForDisplayed(element: WebdriverIO.Element, timeout: number = 10000, message?: string): Promise<void> {
        try {
            await element.waitForDisplayed({
                timeout: timeout,
                timeoutMsg: message || `Element not displayed after ${timeout}ms`
            });
        } catch (error) {
            throw new Error(`Wait for element to be displayed failed: ${error}`);
        }
    }
    
    /**
     * Wait for an element to be clickable with proper error handling
     * @param element WebdriverIO element
     * @param timeout Timeout in milliseconds
     * @param message Error message
     */
    public async waitForClickable(element: WebdriverIO.Element, timeout: number = 10000, message?: string): Promise<void> {
        try {
            await element.waitForClickable({
                timeout: timeout,
                timeoutMsg: message || `Element not clickable after ${timeout}ms`
            });
        } catch (error) {
            throw new Error(`Wait for element to be clickable failed: ${error}`);
        }
    }
    
    /**
     * Safely click an element with proper error handling
     * @param element WebdriverIO element
     */
    public async safeClick(element: WebdriverIO.Element): Promise<void> {
        try {
            await this.waitForClickable(element);
            await element.click();
        } catch (error) {
            throw new Error(`Failed to click element: ${error}`);
        }
    }
    
    /**
     * Safely set value to an input element with proper error handling
     * @param element WebdriverIO element
     * @param value Value to set
     */
    public async safeSetValue(element: WebdriverIO.Element, value: string): Promise<void> {
        try {
            await this.waitForDisplayed(element);
            await element.clearValue();
            await element.setValue(value);
        } catch (error) {
            throw new Error(`Failed to set value "${value}" to element: ${error}`);
        }
    }
    
    /**
     * Get text from an element with proper error handling
     * @param element WebdriverIO element
     * @returns Text content of the element
     */
    public async safeGetText(element: WebdriverIO.Element): Promise<string> {
        try {
            await this.waitForDisplayed(element);
            return await element.getText();
        } catch (error) {
            throw new Error(`Failed to get text from element: ${error}`);
        }
    }
    
    /**
     * Check if an element is displayed with proper error handling
     * @param element WebdriverIO element
     * @returns Boolean indicating if element is displayed
     */
    public async isElementDisplayed(element: WebdriverIO.Element): Promise<boolean> {
        try {
            return await element.isDisplayed();
        } catch (error) {
            return false;
        }
    }
}

// src/pageObjects/loginPage.ts
import BasePage from './basePage';
import { logger } from '../utils/logger';

class LoginPage extends BasePage {
    // Selectors
    get inputUsername() { return $('#loginId'); }
    get inputPassword() { return $('#password'); }
    get btnLogin() { return $('.login-button'); }
    get loginForm() { return $('#loginForm'); }
    get errorMessage() { return $('.login-error-message'); }
    
    /**
     * Open the login page
     */
    public async open(): Promise<void> {
        logger.debug('Opening app login page');
        await super.open('https://client.app.com/Areas/Access/Login');
    }
    
    /**
     * Wait for the login page to load
     */
    public async waitForPageLoad(): Promise<void> {
        logger.debug('Waiting for login page to load');
        await this.waitForDisplayed(this.loginForm, 20000, 'Login form not displayed after timeout');
    }
    
    /**
     * Login with username and password
     * @param username Username
     * @param password Password
     */
    public async login(username: string, password: string): Promise<void> {
        logger.debug(`Logging in with username: ${username}`);
        
        try {
            await this.safeSetValue(this.inputUsername, username);
            await this.safeSetValue(this.inputPassword, password);
            await this.safeClick(this.btnLogin);
            
            // Check for login errors
            if (await this.isElementDisplayed(this.errorMessage)) {
                const error = await this.safeGetText(this.errorMessage);
                throw new Error(`Login failed: ${error}`);
            }
        } catch (error) {
            logger.error(`Login failed: ${error}`);
            throw new Error(`Login failed: ${error}`);
        }
    }
    
    /**
     * Check if error message is displayed
     * @returns Boolean indicating if error message is displayed
     */
    public async isErrorMessageDisplayed(): Promise<boolean> {
        return await this.isElementDisplayed(this.errorMessage);
    }
    
    /**
     * Get login error message
     * @returns Error message text
     */
    public async getErrorMessage(): Promise<string> {
        if (await this.isErrorMessageDisplayed()) {
            return await this.safeGetText(this.errorMessage);
        }
        return '';
    }
}

export default new LoginPage();

// src/pageObjects/dashboardPage.ts
import BasePage from './basePage';
import { logger } from '../utils/logger';

class DashboardPage extends BasePage {
    // Selectors
    get dashboardContainer() { return $('.dashboard-container, .root-app-container'); }
    get accountSummary() { return $('.account-summary, .accounts-overview'); }
    get userProfileInfo() { return $('.user-profile-info, .user-account-name'); }
    get navigationMenu() { return $('.main-navigation, .navigation-menu'); }
    
    /**
     * Wait for dashboard page to load
     */
    public async waitForPageLoad(): Promise<void> {
        logger.debug('Waiting for dashboard page to load');
        await this.waitForDisplayed(this.dashboardContainer, 30000, 'Dashboard not displayed after login timeout');
        await browser.pause(2000); // Additional wait for dynamic content
    }
    
    /**
     * Check if user is logged in
     * @returns Boolean indicating if user is logged in
     */
    public async isUserLoggedIn(): Promise<boolean> {
        try {
            return await this.isElementDisplayed(this.userProfileInfo);
        } catch (error) {
            logger.error(`Failed to verify login status: ${error}`);
            return false;
        }
    }
    
    /**
     * Navigate to a specific menu item
     * @param menuItem Text of the menu item to click
     */
    public async navigateToMenuItem(menuItem: string): Promise<void> {
        logger.debug(`Navigating to menu item: ${menuItem}`);
        
        try {
            const menuSelector = `.navigation-item=${menuItem}, a=${menuItem}`;
            const menuItemElement = $(menuSelector);
            
            await this.waitForDisplayed(this.navigationMenu);
            await this.safeClick(menuItemElement);
        } catch (error) {
            logger.error(`Failed to navigate to ${menuItem}: ${error}`);
            throw new Error(`Failed to navigate to ${menuItem}: ${error}`);
        }
    }
}

export default new DashboardPage();

// src/pageObjects/investmentAllocationPage.ts
import BasePage from './basePage';
import { logger } from '../utils/logger';

class InvestmentAllocationPage extends BasePage {
    // Selectors
    get pageContainer() { return $('.enter-allocations-container, .allocations-content-container'); }
    get pageTitle() { return $('h1=Enter Allocations, .page-title'); }
    get allocationForm() { return $('.allocation-form, form.allocations-form'); }
    get allPoolInputs() { return $$('.investment-pool-input, input[type="text"].allocation-input'); }
    get allPoolNames() { return $$('.investment-pool-name, .pool-name-label'); }
    get btnSubmit() { return $('.submit-button, button.continue-button, button=Next'); }
    get btnReset() { return $('.reset-button, button.clear-button, button=Reset'); }
    get totalAllocation() { return $('.total-allocation, .allocation-total, .total-percentage'); }
    get errorMessage() { return $('.error-message, .allocation-error, .validation-error'); }
    get loader() { return $('.loading-spinner, .spinner'); }
    
    /**
     * Wait for investment allocation page to load
     */
    public async waitForPageLoad(): Promise<void> {
        logger.debug('Waiting for investment allocation page to load');
        
        try {
            // Wait for loader to disappear if present
            if (await this.isElementDisplayed(this.loader)) {
                await browser.waitUntil(
                    async () => !(await this.isElementDisplayed(this.loader)),
                    { timeout: 30000, timeoutMsg: 'Loading spinner still visible after timeout' }
                );
            }
            
            await this.waitForDisplayed(this.pageContainer, 20000, 'Allocation page container not displayed after timeout');
            await this.waitForDisplayed(this.allocationForm, 10000, 'Allocation form not displayed after timeout');
            
            // Verify at least one input field is present
            const inputs = await this.allPoolInputs;
            if (inputs.length === 0) {
                throw new Error('No allocation input fields found on the page');
            }
            
            logger.debug(`Found ${inputs.length} allocation input fields`);
        } catch (error) {
            logger.error(`Failed to verify allocation page loaded: ${error}`);
            throw new Error(`Failed to verify allocation page loaded: ${error}`);
        }
    }
    
    /**
     * Clear all allocation input fields
     */
    public async clearAllAllocations(): Promise<void> {
        logger.debug('Clearing all allocation fields');
        
        try {
            const inputFields = await this.allPoolInputs;
            
            for (const input of inputFields) {
                await input.clearValue();
            }
            
            logger.debug('All allocation fields cleared');
        } catch (error) {
            logger.error(`Failed to clear allocation fields: ${error}`);
            throw new Error(`Failed to clear allocation fields: ${error}`);
        }
    }
    
    /**
     * Set equal allocations across all investment pools
     */
    public async setEqualAllocationsAcrossAllPools(): Promise<void> {
        logger.debug('Setting equal allocations across all pools');
        
        try {
            const inputFields = await this.allPoolInputs;
            const totalFields = inputFields.length;
            
            if (totalFields === 0) {
                throw new Error('No allocation input fields found');
            }
            
            // Calculate equal distribution with whole numbers
            const equalValue = Math.floor(100 / totalFields);
            let remainingValue = 100 - (equalValue * totalFields);
            
            logger.debug(`Setting ${equalValue}% for each of ${totalFields} pools with ${remainingValue}% remainder`);
            
            // Set equal values for all fields except the last one
            for (let i = 0; i < totalFields - 1; i++) {
                await this.safeSetValue(inputFields[i], equalValue.toString());
            }
            
            // Set the last field with any remaining percentage to ensure total is 100%
            const lastFieldValue = equalValue + remainingValue;
            await this.safeSetValue(inputFields[totalFields - 1], lastFieldValue.toString());
            
            // Verify total
            const total = await this.getTotalAllocation();
            logger.debug(`Total allocation after equal distribution: ${total}%`);
            
            if (total !== 100) {
                logger.warn(`Total allocation is ${total}%, expected 100%. Adjusting...`);
                await this.adjustLastFieldToReach100Percent();
            }
        } catch (error) {
            logger.error(`Failed to set equal allocations: ${error}`);
            throw new Error(`Failed to set equal allocations: ${error}`);
        }
    }
    
    /**
     * Set custom allocations based on provided data
     * @param allocations Array of allocation objects with pool name and percentage
     */
    public async setCustomAllocations(allocations: Array<{Pool